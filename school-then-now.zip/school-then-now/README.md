# Then & Now: A School Through the Years

A scrolling journalism story laid out as a walk through campus. Each of the six stops has a before/after photo slider, and a floating mini map shows where the reader is on the route.

## Files

```
index.html   ← the story (edit your text here)
style.css    ← colors, fonts and layout
script.js    ← slider, progress bar and scroll animations
images/      ← your photos
```

## Adding your photos

1. Put your photos in the `images/` folder, e.g. `library-past.jpg` and `library-present.jpg`.
2. In `index.html`, find each `<figure class="compare">` block and change the two `src` paths:
   ```html
   <img class="compare__img" src="images/library-present.jpg" alt="The library today">
   <img class="compare__img compare__img--past" src="images/library-past.jpg" alt="The library in 1985">
   ```
   The **present** photo comes first and the **past** photo second (the past one sits on top and is revealed by the slider).
3. Update the year tags (`1985` / `2026`), the `alt` text and the caption.
4. Delete the placeholder `.svg` files when you're done.

**Tips for good comparisons**
- Shoot the present-day photo from the same spot and angle as the old one.
- Crop each pair to the same shape. The default frame is 3:2; change `aspect-ratio` in `style.css` if your photos are 4:3.
- Resize photos to about 2000px wide so the page loads quickly.

## Editing the campus map

The map is drawn in `index.html` inside `<svg id="campus-map">`. Each building is a `<rect>` with a `<text>` label, so change their `x`, `y`, `width` and `height` to match your real campus.

The route is set by the `points` on the two `<polyline>` lines: one `x,y` pair per stop, in tour order. Each `<g class="map-stop">` marker has to sit on the matching point, so if you move a stop, change its `translate(x y)` as well. The floating mini map copies this map automatically.

## Adding or removing a stop

1. Copy a whole `<section class="stop"> ... </section>` block and give it the next id (`stop-7`) and a `data-name`.
2. Add a point to both `<polyline>` lines, add a matching `<g class="map-stop" data-stop="7">` marker, and add the stop to the `route__list`.
3. Update the "Stop X of 6" labels.

## Adding another slider

Copy one whole `<figure class="compare"> ... </figure>` block, paste it where you want it, and change the images and text. The script picks up new sliders on its own. Add `compare--wide` to the class for an extra-wide panoramic frame.

## Publishing with GitHub Pages

1. Create a new repository on GitHub and upload all of these files (keep the `images` folder).
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, pick **Deploy from a branch**, choose `main` and `/ (root)`, then click **Save**.
4. After a minute your story is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

Note: GitHub Pages file names are case-sensitive, so `Library.JPG` and `library.jpg` are different files.
